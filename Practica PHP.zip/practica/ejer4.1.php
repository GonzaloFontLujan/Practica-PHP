<?PHP
$nombre = $_POST['nombre'];
$trabajo = $_POST['trabajo'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$otras = $_POST['otras'];

$archivo = 'datosejer4.txt';
    if(!file_exists($archivo)) {
fopen($archivo,'w'); 
}
$file= fopen($archivo,'a');
fwrite($file,"Contacto:$nombre $trabajo $telefono $direccion $otras".PHP_EOL);
fclose($file);
?>