<?php


$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$matriculado = $_POST['matriculado'];
$ensenanza = $_POST['ensenanza'];
$mostrar = $_POST['mostrar'];

if ($mostrar == "pantalla") {

 
  echo "<h2>DATOS DEL ALUMNO</h2>";
  echo "<p>Nombre: $nombre</p>";
  echo "<p>Teléfono: $telefono</p>";
  echo "<p>Matriculado: $matriculado</p>";
  echo "<p>Enseñanza: $ensenanza</p>";

} else {

  $archivo = fopen("datos.txt", "a");
  fwrite($archivo, "$nombre|$telefono|$matriculado|$ensenanza\n");
  fclose($archivo);


}

?>