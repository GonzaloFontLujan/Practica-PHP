<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Contactos</h1> 
    <p> para guardar presione el boton <p> 

    <form action="ejer4.1.php" method="post"> 

    <p> Para guardar presione el boton </p> 
    Nombre <input type="text" name="nombre"><br>
   Trabajo <input type="text" name="trabajo"><br>
    Telefono <input type="text" name="telefono"><br>
    Direccion<input type="text" name="direccion"><br>
   Otras <input type="text" name="otras"><br> 
   <input type="submit" value="Guardar">
   <input type="reset" value="Reset">
</form>


</body>

</html>

