<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Jugador1<h1>
<?php 
$tiradas=array();
$jugador1=0;

for($i=1; $i <=6; $i++){
    $dado=rand(1,6);
    $tiradas1[$i]= $dado;
    $jugador1= $jugador1+$dado;
    print "<img src='img/$dado.jpg' width=165>";
}
print "<br>";
 print"<h1> Jugador2 </h1>";
$tiradas2=array();
$jugador2=0;

for($i=1; $i <=6; $i++){
    $dado=rand(1,6);
    $tiradas2[$i]= $dado;
    $jugador2= $jugador2+$dado;
    print "<img src='img/$dado.jpg' width=165>";
}
print "<br>";

echo "RESULTADOS";

if ($jugador1>$jugador2){
    print "<p> El Jugador1 ha ganado con un resultado de $jugador1</p>";
}else{
    if ($jugador1<$jugador2){
        print "<p> El Jugador2 ha ganado con un resultado de $jugador2</p>";
    }else{
        print "<p> Hay un empate</p>";
    }
}

?>
</body>
</html>