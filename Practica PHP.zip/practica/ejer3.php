<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alumno</title>
</head>
<body>

  <h1>DATOS DEL ALUMNO</h1>

  <form action="ejer3.1.php" method="post">

    <input type="text" name="nombre" placeholder="Introduzca su nombre">
    <input type="text" name="telefono" placeholder="Introduzca su teléfono">
    <input type="radio" name="matriculado" value="si"> Sí
    <input type="radio" name="matriculado" value="no"> No
    <select name="ensenanza">
      <option value="secundaria">Secundaria</option>
      <option value="bachillerato">Bachillerato</option>
      <option value="ciclo_medio">Ciclo medio</option>
      <option value="ciclo_superior">Ciclo superior</option>
    </select>
    <input type="radio" name="mostrar" value="pantalla"> Por pantalla
    <input type="radio" name="mostrar" value="archivo"> En archivo
    <input type="submit" value="Enviar datos">

  </form>
 

</body>
</html>
