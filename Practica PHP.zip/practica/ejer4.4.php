<?php
$nombre=$_POST['nombre'];

$fichero="datosejer4.txt";
$fd= fopen($fichero,"r"); //Modo r,read
$existe= false;
while(!feof($fd)){
$linea =fgets($fd);
if (strpos($linea, "Contacto:$nombre") !== false){
echo  " $linea";
$existe=true;
end;
}
}
if ($existe == "false"){
echo "El nombre $nombre no coincide";

}
?>