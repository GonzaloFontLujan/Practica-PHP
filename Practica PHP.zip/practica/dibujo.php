<?php
  
  if ($_POST['ancho'] < 0 || $_POST['alto'] < 0 || $_POST['ancho'] > 100 || $_POST['alto'] > 100) {
    echo "Los valores del formulario no son validos.";
    exit;
  }

  
  for ($i = 0; $i < $_POST['alto']; $i++) {
    for ($j = 0; $j < $_POST['ancho']; $j++) {
      echo "*";
    }
    echo "<br>";
  }
?>